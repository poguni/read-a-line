# 한 줄 독서 (Read a Line) — 제품 요구사항 문서(PRD)

> 독서 챌린지 & 북 빙고 웹앱 · 앱 이름 확정: **한 줄 독서 (Read a Line)** — 빙고 "한 줄"을 완성하는 재미와 책 "한 줄"을 읽는 꾸준함

| 항목 | 내용 |
|---|---|
| 문서 버전 | v2.0 (Supabase 공유 저장·로그인, 폴더 구조, 디자인 가이드 반영) |
| 작성일 | 2026-11-05 (v2.0 수정: 2026-11-06) |
| 문서 위치 | `docs/PRD_한줄독서.md` (보기용 `docs/PRD_한줄독서.html`) |
| 작성자 | 기획자 · Claude(초안 작성 지원) |
| 상태 | 검토 중 |
| 형태 | 단일 HTML 파일 웹앱 + Supabase 저장 (Delicious Library 프로젝트 공유, 로그인 공유 · 테이블 분리) |
| 사용자 | 본인 1명 (개인 전용) |
| 난이도 | ★★ (바이브 코딩 입문~중급) |

---

## 1. 개요

### 1.1 배경
- 연초에 "올해 책 24권 읽기" 같은 목표를 세워도, 숫자만 있는 목표는 중간에 동기를 잃기 쉽습니다.
- 익숙한 분야만 읽게 되는 **편식 독서**도 흔한 고민입니다.
- 빙고는 규칙이 단순하고, "한 줄만 더!"라는 심리가 작동해 꾸준함을 만들기 좋은 게임 형식입니다.

### 1.2 제품 한 줄 정의
**연간 독서 목표를 빙고판과 미션으로 바꿔, 다양한 분야의 책을 즐겁게 꾸준히 읽도록 돕는 개인용 웹앱**

### 1.3 목표
| 구분 | 목표 |
|---|---|
| 사용자 목표 | ① 연간 독서 목표를 끝까지 유지 ② 평소 읽지 않던 분야에 도전 ③ 친구와 함께 즐기기 |
| 제품 목표 | ① 설치 없이 파일 하나로 실행 ② 3×3·4×4·5×5 빙고판 선택 ③ 빙고 완성의 성취감 연출 ④ 목표 대비 진행 속도를 한눈에 제공 ⑤ Delicious Library 계정으로 로그인해 여러 기기에서 같은 기록 사용 |

### 1.4 범위 밖(Non-goals)
- 한 줄 독서만의 별도 회원 가입·인증 시스템 (Delicious Library의 로그인을 공유)
- 여러 사용자를 위한 기능(사용자 관리, 공개 프로필) — 개인 전용 앱
- Delicious Library 데이터와의 연동·통합 (같은 프로젝트를 쓰지만 데이터는 완전히 분리)
- 실시간 친구 랭킹·소셜 피드
- 외부 도서 API 연동(표지·ISBN 자동 검색) → 향후 확장 항목으로 분리

---

## 2. 대상 사용자

> 실제 사용자는 **본인 1명**입니다. 아래 페르소나는 기능과 화면을 설계할 때 참고하는 사용 상황입니다.

| 페르소나 | 특징 | 기대하는 것 |
|---|---|---|
| **새해 다짐형 직장인** (30대) | 1년에 10권 남짓 읽음, 목표는 매년 세우지만 3월에 흐지부지 | 부담 없는 작은 목표, 진행 속도 알림 |
| **독서 모임 운영자** (40대) | 모임원 6~8명과 함께 연간 챌린지 진행 | 같은 빙고판을 이미지로 공유, 각자 채우기 |
| **편식 독서가** (20대) | 소설만 읽음, 다른 분야는 막막함 | 분야별 미션 제안, 작은 판(3×3)으로 가볍게 시작 |
| **학부모·교사** | 아이·학생 독서 지도 | 칸 수를 조절한 쉬운 판, 출력 가능한 이미지 |

---

## 3. 핵심 가치

1. **게임처럼 즐겁게** — 칸을 채우고 줄을 완성할 때마다 시각적 보상
2. **다양하게 읽기** — 미션 칸이 자연스럽게 새로운 분야로 안내
3. **내 속도에 맞게** — 3×3(9권)부터 5×5(25권)까지 판 크기를 직접 선택
4. **가볍고 안전하게** — 설치 없음, 기존 Delicious Library 계정으로 로그인, 내 기록은 RLS로 나만 접근

---

## 4. 사용자 시나리오

### 시나리오 A — 첫 빙고판 만들기
1. 사용자가 앱을 열고 Delicious Library 계정(같은 이메일)으로 로그인합니다.
2. 온보딩 화면에서 **연간 목표 권수**(예: 20권)와 **빙고판 크기**(3×3 / 4×4 / 5×5)를 선택합니다.
3. 앱이 크기에 맞게 미션을 자동 추천하고, 사용자는 원하는 칸을 바꾸거나 직접 입력합니다.
4. "빙고판 완성"을 누르면 메인 화면에 빙고판이 표시됩니다.

### 시나리오 B — 읽은 책 배치하기
1. 『사피엔스』를 다 읽은 사용자가 "책 추가"를 누르고 제목·저자·완독일·쪽수·별점을 입력합니다.
2. 앱이 해당 책과 어울리는 미션 칸(예: "500쪽 넘는 책", "번역서")을 추천합니다.
3. 사용자가 칸을 선택하면 칸이 채워지고, 줄이 완성되면 **빙고 애니메이션**이 재생됩니다.

### 시나리오 C — 진행 속도 확인
1. 9월에 사용자가 진행률 화면을 엽니다.
2. "목표 20권 중 11권(55%) · 남은 기간 17주 · **2주에 1권** 페이스면 달성 가능"과 같은 안내를 봅니다.

### 시나리오 D — 친구와 공유
1. 독서 모임 운영자가 빈 빙고판을 **이미지(PNG)** 로 저장해 단톡방에 공유합니다.
2. 또는 **빙고판 코드**를 복사해 공유하면, 친구가 코드를 붙여 넣어 같은 판을 그대로 불러옵니다.

---

## 5. 기능 요구사항

우선순위: **P0** = 1차 출시 필수 · **P1** = 1차 출시 권장 · **P2** = 향후 확장

### 5.1 빙고판 크기 선택 ⭐ (P0)

사용자는 빙고판을 만들 때 크기를 직접 선택합니다.

| 크기 | 칸 수 | 가능한 빙고 줄 수 | 중앙 무료 칸 | 권장 대상 |
|---|---|---|---|---|
| **3×3** | 9칸 | 8줄 (가로 3 · 세로 3 · 대각 2) | 선택 가능(기본 꺼짐) | 입문자, 연 10권 이하, 어린이 |
| **4×4** | 16칸 | 10줄 (가로 4 · 세로 4 · 대각 2) | 없음(중앙 칸이 없음) | 연 12~20권 |
| **5×5** | 25칸 | 12줄 (가로 5 · 세로 5 · 대각 2) | 선택 가능(기본 켜짐) | 연 20권 이상, 독서 모임 |
| 6×6 (P2) | 36칸 | 14줄 | 없음 | 다독가 |

**세부 요구사항**
- FR-1.1 온보딩과 "새 빙고판 만들기" 화면에서 크기를 카드형 버튼으로 선택합니다. 각 카드에는 미리보기 격자와 "9권 / 16권 / 25권" 안내가 표시됩니다.
- FR-1.2 연간 목표 권수를 입력하면 어울리는 크기를 **추천 배지**로 표시합니다. (목표 ≤ 10권 → 3×3, 11~20권 → 4×4, 21권 이상 → 5×5)
- FR-1.3 홀수 크기(3×3, 5×5)에서는 **중앙 무료 칸(FREE)** 을 켜고 끌 수 있습니다. 무료 칸은 처음부터 채워진 상태로 간주합니다.
- FR-1.4 빙고 판정 로직은 크기 `N`을 매개변수로 받아 가로 `N`줄 · 세로 `N`줄 · 대각선 2줄, 총 `2N + 2`줄을 검사합니다. 크기별로 별도 코드를 만들지 않습니다.
- FR-1.5 이미 책이 배치된 판의 크기를 바꾸려 하면 경고를 띄우고, 다음 중 하나를 고르게 합니다.
  - **새 판으로 시작**: 기존 판은 보관함에 남기고 새 크기의 빈 판을 만듭니다.
  - **책 옮기기**: 기존에 배치된 책을 새 판의 같은 미션 칸으로 옮기고, 미션이 없어진 책은 "미배치 책" 목록으로 보냅니다.
- FR-1.6 화면 너비에 따라 칸 크기를 자동 조절해, 5×5도 휴대폰(360px)에서 가로 스크롤 없이 보이게 합니다. 칸이 작아지면 미션 글자는 2줄까지 말줄임 처리하고 탭하면 전체 내용을 보여 줍니다.

### 5.2 미션 칸 구성 (P0)
- FR-2.1 기본 **미션 라이브러리**(40개 이상, 9장 참고)에서 선택한 크기만큼 미션을 무작위·분야 균형 있게 자동 추천합니다.
- FR-2.2 "다시 섞기" 버튼으로 전체 또는 칸 하나만 다시 추천받을 수 있습니다.
- FR-2.3 칸을 눌러 미션 문구를 직접 수정하거나 라이브러리에서 고를 수 있습니다.
- FR-2.4 칸을 끌어서(드래그) 위치를 바꿀 수 있습니다. (모바일은 길게 누른 뒤 이동) — P1
- FR-2.5 같은 미션이 한 판에 중복되지 않도록 경고합니다.
- FR-2.6 난이도 옵션(쉬움 / 보통 / 도전)에 따라 추천 미션 구성을 달리합니다. — P1

### 5.3 책 기록과 칸 배치 (P0)
- FR-3.1 책 정보: 제목(필수), 저자, 완독일(기본값: 오늘), 쪽수, 별점(1~5), 한 줄 메모, 태그(분야)
- FR-3.2 책 저장 후 "어느 칸에 놓을까요?" 단계에서 빈 칸 목록을 보여 줍니다. 쪽수·태그로 맞는 미션을 추천합니다. (예: 쪽수 ≥ 500 → "500쪽 넘는 책")
- FR-3.3 한 권은 한 칸에만 배치합니다(규칙 엄격 모드). 설정에서 "한 권으로 여러 칸 인정"을 켤 수 있습니다. — P1
- FR-3.4 칸에 배치하지 않은 책도 연간 진행률에는 포함됩니다.
- FR-3.5 채워진 칸에는 책 제목과 체크 표시가 나타나고, 누르면 책 상세(메모·별점) 확인, 배치 해제, 다른 칸으로 이동을 할 수 있습니다.

### 5.4 빙고 판정과 애니메이션 (P0)
- FR-4.1 칸이 채워질 때마다 모든 줄을 검사하고, 새로 완성된 줄만 애니메이션을 재생합니다.
- FR-4.2 줄 완성 연출: 해당 줄 칸이 차례로 빛나는 효과(약 0.6초) + 줄 위에 선 긋기 + "BINGO!" 배지 + 색종이(confetti) 효과
- FR-4.3 **모든 칸 완성(블랙아웃)** 시 특별 축하 화면과 기념 이미지 저장 버튼을 제공합니다.
- FR-4.4 완성된 줄 수를 "빙고 3 / 12"처럼 상단에 표시합니다.
- FR-4.5 운영체제의 "동작 줄이기(prefers-reduced-motion)" 설정을 따르며, 앱 설정에서도 애니메이션을 끌 수 있습니다.
- FR-4.6 효과음은 기본 꺼짐, 설정에서 켤 수 있습니다. — P1

### 5.5 연간 목표와 진행 속도 (P0)
- FR-5.1 연간 목표 권수와 기간(기본: 1월 1일~12월 31일, 사용자 지정 가능)을 설정합니다.
- FR-5.2 진행률 카드에 다음을 표시합니다.
  - 읽은 권수 / 목표 권수, 진행률(%) 원형 그래프
  - 경과 기간 비율 대비 진행률 비교 (예: "기간 70% 경과, 독서 55% 달성 → 조금 늦어요")
  - **필요 속도**: 남은 권수를 남은 기간으로 나눈 값 ("주 0.65권 ≈ 11일에 1권")
  - 현재 속도 유지 시 연말 예상 권수
- FR-5.3 상태 문구는 3단계로 구분합니다: 🟢 순항 중 / 🟡 조금 늦어요 / 🔴 속도를 올려요
- FR-5.4 월별 완독 권수 막대그래프 — P1
- FR-5.5 빙고 목표와 권수 목표를 분리해 관리합니다. (예: 목표는 30권, 빙고판은 4×4)

### 5.6 공유 (P0 이미지 / P1 코드)
- FR-6.1 **이미지 저장**: Canvas로 빙고판을 PNG(1080×1350, SNS 세로 비율)로 그립니다. 앱 이름, 연도, 닉네임, 빙고 수를 함께 넣습니다.
- FR-6.2 이미지 종류: ① 빈 판(친구에게 같은 미션 공유용) ② 내 진행 판(채운 칸과 책 제목 포함)
- FR-6.3 모바일에서는 Web Share API로 바로 공유하고, 지원하지 않으면 파일로 내려받습니다.
- FR-6.4 **빙고판 코드**: 크기·미션 목록을 압축한 문자열(또는 URL 해시)로 복사하고, 친구는 붙여 넣기만 하면 같은 판을 불러옵니다. — P1

### 5.7 데이터 관리 (P0)
- FR-7.1 모든 데이터는 Supabase(`read_a_line` 스키마)에 자동 저장되고, localStorage에는 캐시로 함께 저장됩니다. (7장)
- FR-7.2 **JSON 백업 내보내기 / 가져오기**로 기기 이동과 브라우저 초기화에 대비합니다.
- FR-7.3 연도별 빙고판 보관함: 지난해 판을 읽기 전용으로 다시 볼 수 있습니다. — P1
- FR-7.4 전체 초기화 기능(두 번 확인)

### 5.8 로그인과 동기화 (P0)
- FR-8.1 첫 화면에서 로그인합니다. Delicious Library와 같은 계정·같은 로그인 방식을 쓰며, **회원 가입 버튼은 두지 않습니다.**
- FR-8.2 로그인 상태를 유지하고, 설정 화면에 로그인한 이메일과 로그아웃 버튼을 표시합니다.
- FR-8.3 사이드바(데스크톱)·상단 바(모바일)에 동기화 상태(저장됨 · 저장 중 · 오프라인)를 작게 표시합니다.
- FR-8.4 로그인 전이거나 오프라인이면 마지막 캐시를 보여 주고, 변경 내용은 대기열에 쌓았다가 연결되면 저장합니다.
- FR-8.5 첫 로그인 때 이 기기에 로그인 전 기록이 있으면 "이 기기 기록 올리기"를 한 번 제안합니다.
- FR-8.6 로그인 없이 "샘플 데이터로 둘러보기"(데모 모드)를 쓸 수 있으며, 이때는 아무것도 저장하지 않습니다.

### 5.9 기타 (P1~P2)
- 다크 모드(시스템 설정 연동) — P1
- 칸 테마 색상 5종 선택 — P1
- 6×6 빙고판, 직사각형 판 — P2
- 도서 검색 API로 표지·쪽수 자동 입력 — P2
- PWA(홈 화면 추가, 오프라인 캐시) — P2

---

## 6. 화면 구성

### 6.1 화면 목록
| 화면 | 주요 요소 |
|---|---|
| ① 온보딩 | 연간 목표 입력 → 빙고판 크기 선택(3×3/4×4/5×5) → 미션 확인·수정 |
| ② 홈(빙고판) | 상단 진행 요약, 빙고판, 빙고 수, "책 추가" 버튼 |
| ③ 책 추가/편집 | 책 정보 입력 → 칸 선택 단계 |
| ④ 내 책장 | 읽은 책 목록(배치됨/미배치 필터), 정렬, 검색 |
| ⑤ 진행률 | 목표 대비 진행률, 필요 속도, 월별 그래프 |
| ⑥ 공유 | 이미지 미리보기·저장, 빙고판 코드 복사/불러오기 |
| ⑦ 설정 | 판 크기 변경, 무료 칸, 애니메이션, 다크 모드, 백업/복원, 초기화, 계정(이메일·로그아웃) |
| ⑧ 로그인 | 이메일·비밀번호(또는 매직 링크) 입력, 샘플 둘러보기 — 가입 버튼 없음 |

### 6.2 홈 화면 와이어프레임 (4×4 예시)

```
┌──────────────────────────────────┐
│  한 줄 독서              ⚙️  📤  │
│  2026 · 11권 / 20권  ████░░ 55%  │
│  🟡 조금 늦어요 · 11일에 1권 필요   │
├──────────────────────────────────┤
│  [3×3] [4×4●] [5×5]   빙고 2/10  │
│ ┌──────┬──────┬──────┬──────┐    │
│ │500쪽+│번역서│ 시집 │신간  │    │
│ │ ✅사피│ ✅   │      │      │    │
│ ├──────┼──────┼──────┼──────┤    │
│ │과학  │여행  │ 고전 │만화  │    │
│ │ ✅   │ ✅   │      │      │    │
│ ├──────┼──────┼──────┼──────┤    │
│ │ ...  │ ...  │ ...  │ ...  │    │
│ └──────┴──────┴──────┴──────┘    │
│                                  │
│          [ + 읽은 책 추가 ]        │
├──────────────────────────────────┤
│  🏠 빙고판   📚 책장   📈 진행률   │
└──────────────────────────────────┘
```

> 상단의 크기 표시는 현재 판 크기를 보여 주는 용도이며, 누르면 FR-1.5의 크기 변경 확인 창이 열립니다.

### 6.3 디자인 방향
- 콘셉트: **"따뜻한 서재 + 경쾌한 게임"** — 종이 질감의 아이보리 배경, 책등을 닮은 칸 색상, 빙고 순간에는 선명한 강조색
- 테마별 색·글꼴·컴포넌트 규칙은 **`design/DESIGN.md`** 를 기준으로 합니다.
- 칸 상태 3가지: 빈 칸(점선 테두리) / 채운 칸(색 채움 + 체크) / 빙고 줄(빛나는 테두리)
- 터치 영역 최소 44×44px (5×5 휴대폰 화면에서도 확보)

### 6.4 테마 시스템 (P1)

디자인 시안 3종을 모두 구현하고, 설정에서 테마를 고를 수 있게 합니다. **테마는 겉모습만 바꾸고 기능·화면 구조·데이터는 똑같이 유지**합니다.

| 테마 | 콘셉트 | 색상 | 글꼴 | 빙고 칸 표현 |
|---|---|---|---|---|
| **A 고풍 서재** (Library Classic) | 오래된 서재와 도서관, 가죽 장정과 황동 장식 | 짙은 녹색 `#24412F` · 버건디 `#6E2230` · 황동 `#C9A35C` · 양피지 `#EFE5CF` | 나눔명조 · 고운바탕 · Cormorant Garamond | 빈 칸은 점선 카드, 채운 칸은 녹색 장정, 빙고 줄은 버건디 + 황동 테두리 |
| **B 빙고 팝** (Bingo Pop) | 빙고 게임장, 빙고 공과 도장 | 코랄 `#FF6B5B` · 옐로 `#FFD84D` · 민트 `#4FD1B0` · 크림 `#FFF4E2` · 잉크 `#2B2433` | 주아 · 고운돋움 · Fredoka | 두꺼운 테두리와 그림자의 말랑한 칸, 채운 칸은 노랑, 빙고 줄은 민트 |
| **C 모던 마일스톤** (Modern Milestone) | 꾸준함이 쌓여 목표에 닿는 세련된 대시보드 | 잉크 `#121417` · 블루 `#3550E6` · 웜 그레이 `#F4F3EF` | IBM Plex Sans KR · Inter Tight | 얇은 선의 미니멀 칸, 채운 칸은 검정, 빙고 줄은 블루 |

**테마 간 공통 규칙(기능 동일성)**
- 모든 테마에서 같은 화면 구성: 상단 진행 요약 → 빙고판 크기 선택(3×3/4×4/5×5) → 빙고 수 → 빙고판 → "읽은 책 추가" 버튼 → 하단 메뉴 4개(빙고판·책장·진행률·설정)
- 칸 상태 4가지(빈 칸 / 채운 칸 / 빙고 줄 / 무료 칸)를 모든 테마에서 같은 의미로 표현하고, 색 외에 책 제목·테두리로도 구분
- 진행률 화면도 같은 정보(원형 달성률, 기간 경과 대비 진행, 필요 속도·남은 기간·연말 예상, 월별 완독, 빙고 현황)를 제공하며, 그래프 모양만 테마에 맞게 바꿈 (A 막대, B 빙고 공 쌓기, C 누적 선 그래프)
- 구현: 색·글꼴·모서리·그림자를 CSS 변수(`--bg`, `--ink`, `--cell-filled`, `--cell-bingo`, `--radius` 등)로 정의하고, `<html data-theme="library|pop|modern">` 값만 바꿔 전환
- 테마 선택은 `profile.theme`에 저장하고, 공유 이미지(Canvas)도 현재 테마 색으로 그림
- 모든 테마의 글자 명도 대비 4.5:1 이상 유지

### 6.5 데스크톱 반응형 레이아웃 (P0)

기준 화면은 16:10 **1440×900**이며, 화면 너비 1024px 이상에서 데스크톱 레이아웃으로 바뀝니다. 콘텐츠를 가운데에 좁게 모으지 않고 **화면 전체 너비를 사용**합니다.

| 영역 | 데스크톱 (≥1024px) | 모바일 (<1024px) |
|---|---|---|
| 내비게이션 | 왼쪽 고정 사이드바(256px): 브랜드, 메뉴 4개, 테마 빠른 전환, 연간 진행 요약 | 상단 바 + 하단 탭 메뉴 4개 |
| 빙고판 화면 | 2단: 왼쪽은 화면 높이에 맞춘 큰 빙고판(1440×900 기준 약 700px), 오른쪽은 진행 요약·필요 속도·빙고 현황·미배치 책·최근 읽은 책 패널(남는 너비를 모두 사용, 넓은 화면에서는 2열) | 1단: 진행 요약 → 크기 선택 → 빙고판 → 책 추가 버튼 → 보조 카드 |
| 책장 | 화면 너비에 따라 3~5열 책 카드 그리드 | 1열 카드 |
| 진행률 | 12열 그리드 대시보드(달성률·기간 비교·필요 속도 / 월별 그래프·빙고 현황·올해의 기록) | 카드 세로 나열 |
| 설정 | 2열 카드(테마는 전체 너비) | 1열 |
| 첫 화면(온보딩) | 좌우 분할: 왼쪽 소개와 빙고판 그림, 오른쪽 설정 양식 | 양식만 표시 |
| 대화상자 | 화면 가운데 창(책 추가는 입력 양식과 칸 선택판을 좌우로 배치) | 아래에서 올라오는 시트 |

- 빙고판 칸 글자 크기는 컨테이너 쿼리 단위(`cqw`)와 판 크기(`--n`)로 자동 조절합니다.
- 360px 휴대폰부터 1920px 이상 모니터까지 가로 스크롤이 생기지 않아야 합니다.

### 6.6 구현 현황

- v1 구현 파일: `index.html`(테마 선택형, localStorage 저장). 디자인 시안은 `design/시안_고풍서재.html`, `design/시안_빙고팝.html`, `design/시안_모던마일스톤.html`이며, 테마마다 데스크톱(1440×900)과 스마트폰(390×844)의 빙고판·진행률·책장·설정 화면을 실제 앱으로 띄워 보여 줍니다.
- 구현 범위: 온보딩(테마·목표·판 크기·무료 칸), 샘플 데이터, 3×3/4×4/5×5 빙고판과 크기 변경(책 옮기기·새 판), 칸별 책 배치·미션 편집·빈 칸 미션 섞기, 빙고 판정(2N+2줄)과 줄 긋기·BINGO 연출·색종이·블랙아웃 축하, 책장(검색·필터·정렬), 진행률 대시보드, 공유 이미지(PNG 1080×1350)와 빙고판 코드, JSON 백업·복원, 전체 초기화(두 번 확인), 애니메이션 끄기.
- v2에서 할 일: Supabase 저장·로그인(5.8절, 7장).
- 다음 단계로 미룬 항목: 다크 모드, 칸 끌어서 옮기기, 난이도 옵션, 효과음, 6×6 판.

---

## 7. 데이터 저장 구조 (Supabase · Delicious Library 프로젝트 공유)

### 7.1 기본 원칙

한 줄 독서는 기존 독서 앱 **Delicious Library**의 Supabase 프로젝트를 함께 씁니다. **로그인(인증)은 공유하고, 데이터 테이블은 전용 스키마로 완전히 분리**해서 두 앱이 서로 영향을 주지 않게 합니다. 사용자는 본인 1명입니다.

| 구분 | 공유하는 것 | 분리하는 것 |
|---|---|---|
| 프로젝트 | Supabase 프로젝트 「Delicious Library」(같은 URL·같은 공개 키) | — |
| 인증 | `auth.users` 계정, 로그인 방식, 로그인 계정(같은 이메일) | 브라우저 세션 저장 키(`read-a-line-auth`) |
| 데이터 | — | 전용 스키마 **`read_a_line`** 의 테이블 5개 |
| 권한 | — | 테이블마다 RLS 정책(본인 행만 읽기·쓰기) |
| 마이그레이션 | — | `supabase/migrations/*_ral_*.sql` 파일로 따로 관리 |
| 파일 저장소 | — | (필요해지면) 전용 버킷 `read-a-line` |

### 7.2 로그인 공유 방식

- Delicious Library와 **같은 계정·같은 로그인 방식**(예: 이메일 + 비밀번호 또는 매직 링크)을 그대로 씁니다. 한 줄 독서에는 **회원 가입 화면을 만들지 않고 로그인만** 제공합니다.
- 두 앱의 주소(도메인)가 다르면 브라우저 로그인 상태는 따로 저장되므로, 각 앱에서 같은 계정으로 한 번씩 로그인합니다.
- 클라이언트의 세션 저장 키를 `read-a-line-auth`로 지정해, 같은 도메인에서 함께 쓰더라도 한쪽 로그아웃이 다른 쪽에 영향을 주지 않게 합니다.
- 매직 링크·소셜 로그인을 쓰는 경우, Supabase 대시보드 **Authentication → URL Configuration → Redirect URLs** 에 한 줄 독서 주소만 **추가**합니다. **Site URL과 가입 허용 여부 등 나머지 인증 설정은 Delicious Library 값을 그대로 둡니다.**
- HTML 파일을 더블클릭(`file://`)으로 열면 매직 링크·소셜 로그인 리디렉션이 동작하지 않습니다. 이 경우 **이메일 + 비밀번호 로그인**을 쓰거나, 정적 호스팅(예: GitHub Pages, Netlify)에 올려 고정 주소로 사용합니다.
- 로그인 없이도 **샘플 데이터 둘러보기(데모 모드, 저장 안 함)** 는 쓸 수 있습니다.

### 7.3 전용 스키마와 테이블

모든 테이블은 `read_a_line` 스키마에만 만들고, Delicious Library의 `public` 스키마 테이블과는 외래 키·조인·트리거로 연결하지 않습니다. 사용자 연결은 `auth.users(id)` 하나만 참조합니다.

| 테이블 | 용도 | 주요 열 |
|---|---|---|
| `settings` | 사용자 설정(1인 1행) | `user_id`(PK), `nickname`, `theme`, `motion`, `active_board_id`, `updated_at` |
| `goals` | 연도별 목표 | `id`, `user_id`, `year`, `target_books`, `start_date`, `end_date` — `(user_id, year)` 고유 |
| `books` | 읽은 책 | `id`, `user_id`, `title`, `author`, `finished_at`, `pages`, `rating`, `memo`, `tags[]` |
| `boards` | 빙고판 | `id`, `user_id`, `year`, `title`, `size(3·4·5)`, `free_center`, `completed_lines[]`, `archived` |
| `board_cells` | 빙고판 칸 | `(board_id, idx)` PK, `user_id`, `mission`, `is_free`, `book_id` |

```sql
-- supabase/migrations/20261106000000_ral_init.sql
create schema if not exists read_a_line;
grant usage on schema read_a_line to authenticated;

create table read_a_line.settings (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  nickname text,
  theme text not null default 'library' check (theme in ('library','pop','modern')),
  motion boolean not null default true,
  active_board_id uuid,
  updated_at timestamptz not null default now()
);

create table read_a_line.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  year int not null,
  target_books int not null check (target_books > 0),
  start_date date not null,
  end_date date not null check (end_date >= start_date),
  updated_at timestamptz not null default now(),
  unique (user_id, year)
);

create table read_a_line.books (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null,
  author text,
  finished_at date not null,
  pages int check (pages > 0),
  rating smallint check (rating between 0 and 5),
  memo text,
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table read_a_line.boards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  year int not null,
  title text not null,
  size smallint not null check (size in (3,4,5)),
  free_center boolean not null default false,
  completed_lines text[] not null default '{}',
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table read_a_line.board_cells (
  board_id uuid not null references read_a_line.boards(id) on delete cascade,
  idx smallint not null,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  mission text not null,
  is_free boolean not null default false,
  book_id uuid references read_a_line.books(id) on delete set null,
  updated_at timestamptz not null default now(),
  primary key (board_id, idx)
);

create index on read_a_line.books (user_id, finished_at);
create index on read_a_line.boards (user_id, year);
create index on read_a_line.board_cells (book_id);
```

### 7.4 권한(RLS)과 API 노출

```sql
-- 모든 테이블: RLS 켜기 + 본인 행만 허용
alter table read_a_line.settings    enable row level security;
alter table read_a_line.goals       enable row level security;
alter table read_a_line.books       enable row level security;
alter table read_a_line.boards      enable row level security;
alter table read_a_line.board_cells enable row level security;

create policy "ral_own_rows" on read_a_line.settings    for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "ral_own_rows" on read_a_line.goals       for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "ral_own_rows" on read_a_line.books       for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "ral_own_rows" on read_a_line.boards      for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "ral_own_rows" on read_a_line.board_cells for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- 로그인한 사용자에게만 권한 부여 (anon에는 부여하지 않음)
grant select, insert, update, delete on all tables in schema read_a_line to authenticated;
```

- 대시보드 **Project Settings → Data API → Exposed schemas** 에 `read_a_line`을 **추가**합니다(기존 `public` 등은 그대로 둠).
- 클라이언트는 공개(anon/publishable) 키만 사용합니다. RLS가 켜져 있어 키가 HTML에 보여도 다른 사람이 데이터를 읽을 수 없습니다. **`service_role` 키는 앱 코드나 저장소에 절대 넣지 않습니다.**

```js
// 단일 HTML에서 CDN으로 불러오기 (버전 고정)
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js"></script>
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  db: { schema: 'read_a_line' },                         // 기본 스키마를 read_a_line으로
  auth: { storageKey: 'read-a-line-auth', persistSession: true }
});
await sb.auth.signInWithPassword({ email, password });   // Delicious Library와 같은 계정
const { data } = await sb.from('books').select('*').order('finished_at', { ascending: false });
```

### 7.5 동기화와 로컬 캐시

| 항목 | 방식 |
|---|---|
| 기준 데이터 | Supabase `read_a_line` 스키마 |
| 로컬 캐시 | localStorage `readALine:v1`(v1 구조 그대로) — 빠른 첫 화면과 오프라인 읽기용 |
| 저장 시점 | 변경 즉시 화면 먼저 반영(낙관적 업데이트) → Supabase에 저장 |
| 실패 처리 | 오프라인·오류 시 대기열(`readALine:v1:queue`)에 쌓고, 연결되면 순서대로 다시 보냄 |
| 충돌 | 혼자 쓰는 앱이므로 `updated_at` 기준 마지막 수정 우선 |
| 첫 로그인 | 이 기기에 로그인 전 기록이 있으면 "이 기기 기록 올리기"를 1회 제안(ID 새로 발급 후 연결) |
| 빙고 줄 | `completed_lines`는 앱이 계산한 결과를 함께 저장(애니메이션 판정용) |
| 백업 | JSON 내보내기·가져오기는 계속 제공 |

### 7.6 Delicious Library에 영향을 주지 않기 위한 규칙

- [ ] 모든 SQL에 `read_a_line.` 스키마 이름을 붙여 작성합니다.
- [ ] `public` 스키마와 Delicious Library 테이블·함수·뷰를 만들거나 바꾸거나 지우지 않습니다(조인·외래 키도 만들지 않음).
- [ ] `auth.users`에 트리거를 추가하지 않습니다. `settings` 행은 첫 로그인 때 앱이 `upsert`로 만듭니다.
- [ ] 정책·인덱스·마이그레이션 이름에 `ral_` 접두어를 붙여 출처를 구분합니다.
- [ ] 인증 설정은 Redirect URLs **추가** 외에는 바꾸지 않습니다.
- [ ] 파일 저장이 필요해지면 전용 버킷 `read-a-line`을 따로 만듭니다.
- [ ] 한 줄 독서를 정리할 때는 `drop schema read_a_line cascade;` 한 줄로 Delicious Library에 영향 없이 제거할 수 있습니다.
- [ ] 무료 플랜 용량·요청 한도는 두 앱이 함께 쓰므로, 책 1,000권 기준 수 MB 수준인지 분기마다 확인합니다.

### 7.7 로컬 캐시 JSON 구조 (v1과 동일)

```json
{
  "version": 1,
  "profile": { "nickname": "책벌레", "theme": "library", "motion": true },
  "goals": { "2026": { "targetBooks": 24, "start": "2026-01-01", "end": "2026-12-31" } },
  "boards": [{ "id": "…", "year": 2026, "title": "2026 나의 북 빙고", "size": 5, "freeCenter": true,
               "cells": [{ "mission": "500쪽 넘는 책", "bookId": "…" }, { "mission": "FREE", "free": true }],
               "completedLines": ["row-1", "diag-main"], "archived": false }],
  "activeBoardId": "…",
  "books": [{ "id": "…", "title": "사피엔스", "author": "유발 하라리", "finishedAt": "2026-01-06",
              "pages": 636, "rating": 5, "memo": "", "tags": ["역사", "번역서"] }]
}
```

- `cells` 길이는 항상 `size × size`이며, 칸 위치는 `idx = 행 × size + 열`입니다(`board_cells.idx`와 같음).
- 줄 식별자: `row-{r}`, `col-{c}`, `diag-main`(왼쪽 위→오른쪽 아래), `diag-anti`(오른쪽 위→왼쪽 아래)

---

## 8. 핵심 로직

### 8.1 빙고 판정 (크기 N 공통)

```js
function getLines(N) {
  const lines = [];
  for (let r = 0; r < N; r++) lines.push({ id: `row-${r}`, cells: [...Array(N)].map((_, c) => r * N + c) });
  for (let c = 0; c < N; c++) lines.push({ id: `col-${c}`, cells: [...Array(N)].map((_, r) => r * N + c) });
  lines.push({ id: 'diag-main', cells: [...Array(N)].map((_, i) => i * N + i) });
  lines.push({ id: 'diag-anti', cells: [...Array(N)].map((_, i) => i * N + (N - 1 - i)) });
  return lines; // 총 2N + 2줄
}

function checkBingo(board) {
  const filled = (i) => board.cells[i].bookId || board.cells[i].missionId === 'free';
  const done = getLines(board.size).filter(l => l.cells.every(filled)).map(l => l.id);
  const newly = done.filter(id => !board.completedLines.includes(id));
  board.completedLines = done;
  return newly; // 새로 완성된 줄만 애니메이션
}
```

### 8.2 진행 속도 계산

| 값 | 계산식 |
|---|---|
| 남은 권수 | `max(목표 − 읽은 권수, 0)` |
| 남은 일수 | `종료일 − 오늘 + 1` |
| 필요 속도(주당) | `남은 권수 ÷ (남은 일수 ÷ 7)` |
| "○일에 1권" | `남은 일수 ÷ 남은 권수` (소수점 버림) |
| 기간 경과율 | `(오늘 − 시작일 + 1) ÷ 전체 일수` |
| 예상 연말 권수 | `읽은 권수 ÷ 경과 일수 × 전체 일수` (반올림) |
| 상태 | 진행률 ≥ 경과율 → 🟢 / 경과율 − 10%p 이내 → 🟡 / 그 외 → 🔴 |

예외 처리: 목표 달성 시 "🎉 목표 달성! 보너스 독서 중", 기간 종료 후에는 결과 요약만 표시합니다.

### 8.3 크기별 미션 추천 알고리즘
1. 미션 라이브러리를 분야(카테고리)별로 묶습니다.
2. 필요한 칸 수(`N×N`, 무료 칸이 있으면 1개 제외)만큼 카테고리를 돌아가며 1개씩 무작위로 뽑습니다. → 분야 편중 방지
3. 난이도 옵션에 따라 "도전" 미션(예: 700쪽 이상, 원서) 비율을 조절합니다. (쉬움 0% · 보통 10% · 도전 25%)
4. 3×3에서는 쉬운 미션 위주로 구성합니다.

---

## 9. 미션 라이브러리 (초기 44개)

| 카테고리 | 미션 예시 |
|---|---|
| 분량·형식 | 500쪽 넘는 책 · 200쪽 이하 얇은 책 · 단편집 · 시집 · 그래픽노블/만화 · 오디오북 · 전자책 |
| 출처·언어 | 번역서 · 원서로 읽기 · 아시아 작가의 책 · 아프리카·남미 작가의 책 · 내가 태어나기 전에 나온 책 |
| 시기 | 올해 나온 신간 · 100년 넘은 고전 · 출간 10주년 된 책 · 내 생일 달에 읽은 책 |
| 분야(인문·사회) | 역사 · 철학 · 심리학 · 경제·경영 · 통계 교양서 · 정치·사회 이슈 |
| 분야(과학·기술) | 과학 교양서 · 수학 이야기 · IT·AI 관련 책 · 환경·기후 |
| 분야(문학) | 추리·스릴러 · SF·판타지 · 로맨스 · 청소년 소설 · 한국 고전 문학 |
| 생활·취미 | 여행 에세이 · 요리·음식 · 운동·건강 · 그림·예술 · 음악 |
| 경험·관계 | 친구가 추천한 책 · 도서관에서 빌린 책 · 표지만 보고 고른 책 · 영화·드라마 원작 · 작가의 데뷔작 · 다시 읽는 책 · 독서 모임 선정 도서 |

---

## 10. 비기능 요구사항

| 구분 | 요구사항 |
|---|---|
| 형태 | **단일 HTML 파일**(HTML·CSS·JS 인라인). 로그인·저장에는 인터넷이 필요하고, 오프라인에서는 캐시로 읽기와 대기열 저장 |
| 외부 의존성 | `@supabase/supabase-js`(CDN, 버전 고정) 1개, Google Fonts. 그 외 효과는 직접 구현 |
| 호환성 | 최신 Chrome·Safari·Edge·Samsung Internet, iOS 16+·Android 10+ |
| 반응형 | 360px 휴대폰 ~ 1440px 데스크톱, 가로 스크롤 없음 |
| 성능 | 첫 화면 1초 이내, 칸 채움→애니메이션 시작 100ms 이내 |
| 저장 | Supabase `read_a_line` 스키마(기준) + localStorage 캐시(5MB 이내). 저장 실패 시 대기열 재시도와 안내 |
| 접근성 | 키보드로 칸 이동·선택, 칸마다 `aria-label`("2행 3열, 번역서, 완료"), 명도 대비 4.5:1 이상, 색만으로 상태를 구분하지 않음(체크 아이콘 병행) |
| 개인정보·보안 | 기록은 본인 Supabase 프로젝트에만 저장. 모든 테이블 RLS(본인 행만), 공개 키만 사용하고 `service_role` 키는 사용 금지. 공유는 사용자가 직접 이미지·코드를 내보낼 때만 |
| 격리 | Delicious Library의 테이블·인증 설정에 영향 없음(7.6절 규칙) |
| 언어 | 한국어 기본, 문구는 한곳(객체)에 모아 향후 영어 지원 가능하게 |

---

## 11. 기술 설계

- **구성**: `index.html` 하나에 `<style>`과 `<script>`를 포함
- **구조(바닐라 JS)**
  - `state` — 앱 전체 데이터(7장 스키마)
  - `store` — `load()`, `save()`(디바운스 300ms), `export()`, `import()`, `migrate()` — 로컬 캐시
  - `auth` — Supabase 로그인·로그아웃·세션 복원(`storageKey: read-a-line-auth`)
  - `sync` — Supabase 읽기·쓰기, 대기열 재시도, 첫 로그인 기록 올리기, 동기화 상태 표시
  - `bingo` — `getLines(N)`, `checkBingo()`, `recommendMissions(N, level)`, `resizeBoard()`
  - `pace` — 진행 속도 계산 함수(8.2)
  - `render` — 화면별 렌더 함수, 상태 변경 시 다시 그림
  - `share` — Canvas 이미지 생성, 빙고판 코드 인코딩/디코딩
  - `fx` — 줄 하이라이트, 색종이 효과(Canvas 파티클)
- **격자 레이아웃**: CSS Grid `grid-template-columns: repeat(var(--n), 1fr)`, `--n` 값만 바꿔 3×3/4×4/5×5 대응
- **칸 글자 크기**: `clamp()`와 `--n` 값을 이용해 크기별 자동 조정
- **빙고판 코드**: `JSON → encodeURIComponent → btoa` 기반 문자열, 앞에 버전 접두어(`RAL1:`)

---

## 12. 개발 일정 (바이브 코딩 단계별)

| 단계 | 내용 | 산출물 | 예상 |
|---|---|---|---|
| 1 | 기본 뼈대: 크기 선택(3/4/5) + 빙고판 렌더링 + 칸 미션 편집 | 크기별 판이 그려지는 HTML | 0.5일 |
| 2 | 책 추가 → 칸 배치 → 빙고 판정(2N+2줄) | 판정 로직 완성 | 0.5일 |
| 3 | localStorage 저장·불러오기, 백업/복원 | 새로고침해도 유지 | 0.5일 |
| 4 | 빙고 애니메이션·색종이·블랙아웃 축하 | 연출 완성 | 0.5일 |
| 5 | 연간 목표·진행 속도 화면 | 진행률 카드 | 0.5일 |
| 6 | 이미지 공유(Canvas), 빙고판 코드 | PNG 저장 | 0.5일 |
| 7 | 크기 변경 시 책 옮기기, 다크 모드, 접근성 점검, 모바일 테스트 | v1.0 | 1일 |
| 8 | 테마 3종(고풍 서재·빙고 팝·모던 마일스톤) CSS 변수화, 설정에서 테마 선택 | 테마 전환 | 1일 |
| 9 | `read_a_line` 스키마 마이그레이션, RLS, Exposed schemas 설정 | SQL 적용 | 0.5일 |
| 10 | 로그인 화면, 세션 유지, 로그아웃 | 로그인 | 0.5일 |
| 11 | Supabase 동기화, 대기열, 첫 로그인 기록 올리기, 동기화 상태 표시 | v2.0 | 1.5일 |
| 12 | Delicious Library 회귀 확인(기존 앱 로그인·데이터 정상 동작) | 확인 보고서(`docs/`) | 0.5일 |

**총 약 8일** (하루 2~3시간 기준 3주 안팎)

---

## 13. 성공 지표

| 지표 | 목표(본인·지인 30명 시범 사용 기준) |
|---|---|
| 온보딩 완료율 (빙고판 생성까지) | 90% 이상 |
| 첫 줄 빙고 달성까지 걸린 기간 | 평균 6주 이내 (4×4 기준) |
| 3개월 뒤에도 책을 기록하는 비율 | 50% 이상 |
| 이미지 공유 1회 이상 사용 비율 | 40% 이상 |
| 기록된 책의 분야(태그) 수 | 사용자당 평균 5개 이상 |

---

## 14. 위험 요소와 대응

| 위험 | 대응 |
|---|---|
| 브라우저 데이터 삭제로 기록 유실 | Supabase가 기준 데이터이므로 다시 로그인하면 복원, JSON 백업도 유지 |
| 한 줄 독서 작업이 Delicious Library에 영향 | 전용 스키마·`ral_` 접두어·7.6절 체크리스트, 적용 전 SQL 검토, 적용 후 Delicious Library 회귀 확인 |
| 인증 설정 변경으로 기존 앱 로그인 문제 | Site URL 등은 바꾸지 않고 Redirect URLs 추가만 허용 |
| `file://`로 열 때 매직 링크 로그인 불가 | 이메일+비밀번호 로그인 사용 또는 정적 호스팅 주소로 사용 |
| 무료 플랜 한도(용량·요청·일시 정지) | 두 앱 합산 사용량을 분기마다 확인, 로컬 캐시로 요청 수 줄이기 |
| 5×5 판이 휴대폰에서 답답함 | 칸 탭 시 확대 보기, 미션 문구 축약 표시, 가로 모드 지원 |
| 미션 판정이 애매함("이 책이 과학 교양서인가?") | 판정은 사용자 자율, "내 기준으로 인정" 원칙 안내 |
| 목표가 너무 커 중도 포기 | 크기 추천 배지, 연중 목표 수정 허용 |
| 이미지 속 한글 글꼴 깨짐 | Canvas에 시스템 글꼴 지정, 렌더 전 `document.fonts.ready` 대기 |

---

## 15. 향후 확장 (v2 이후)
- 독서 모임 모드: 같은 판 코드로 참여, 멤버별 진행 이미지 합치기
- 도서 검색 API 연동(표지·쪽수·분야 자동 입력)
- 월간 미니 빙고(3×3) + 연간 빙고(5×5) 동시 운영
- 배지·업적 시스템(첫 빙고, 블랙아웃, 10개 분야 정복 등)
- PWA 설치, 오프라인 우선 동기화 고도화
- Delicious Library 장서와 연결(선택): 읽은 책을 Delicious Library 책 정보에서 불러오기 — 이때도 읽기 전용 조회만 허용

---

## 16. 프로젝트 폴더 구조와 문서 관리

기획·개발 문서는 **`docs/`**, 디자인 가이드와 시안은 **`design/`** 폴더에 저장합니다.

```
read-a-line/
├─ index.html                     # 앱 본체 (단일 HTML)
├─ docs/                          # 기획·개발 문서
│  ├─ PRD_한줄독서.md             # 제품 요구사항 문서 (원본)
│  ├─ PRD_한줄독서.html           # 같은 내용의 보기·인쇄용
│  └─ 개발보고서_YYYY-MM-DD_주제.md  # 단계별 개발 보고서 (앞으로 추가)
├─ design/                        # 디자인 가이드와 시안
│  ├─ DESIGN.md                   # 디자인 가이드 (토큰·컴포넌트·레이아웃 규칙)
│  ├─ 시안_고풍서재.html          # 데스크톱 + 스마트폰 시안
│  ├─ 시안_빙고팝.html
│  └─ 시안_모던마일스톤.html
└─ supabase/
   └─ migrations/                 # read_a_line 스키마 SQL (파일 이름에 ral_ 포함)
```

| 폴더 | 넣는 문서 | 규칙 |
|---|---|---|
| `docs/` | PRD, 개발 보고서, 회의·결정 기록, 테스트 결과 | Markdown을 원본으로 두고, 공유·인쇄용 HTML을 함께 만듭니다. PRD를 고치면 문서 정보 표의 버전·수정일을 갱신합니다. 개발 보고서는 `개발보고서_YYYY-MM-DD_주제.md` 형식으로 이름 짓습니다. |
| `design/` | DESIGN.md, 테마별 시안 HTML, 아이콘·이미지 원본 | 디자인을 바꿀 때는 DESIGN.md를 먼저 고치고 시안과 앱에 반영합니다. 시안 파일은 `시안_테마명.html`로 이름 짓고, 테마마다 데스크톱(1440×900)과 스마트폰(390×844) 화면을 모두 담습니다. |
| `supabase/` | 마이그레이션 SQL | 7.6절 규칙을 따르며, `read_a_line` 스키마 밖의 객체를 다루는 SQL은 두지 않습니다. |

- 디자인 캔버스(온라인 시안): https://claude.ai/artifact/NEm6ALBs9TEc9z5p7e2RJ9

---

## 부록 A. 앱 이름 후보

| # | 한글 이름 | 영어 이름 | 의미 |
|---|---|---|---|
| 1 | **한 줄 독서** | **Read a Line** | 빙고 "한 줄"을 완성하는 재미와 책 "한 줄"을 읽는 꾸준함을 함께 담은 이름 |
| 2 | **책칸** | **Bookingo** | 책장의 "칸"과 빙고판의 "칸"이 겹치는 이름, Book + Bingo 합성어 |
| 3 | **칸칸서재** | **Bingo Shelf** | 칸칸이 채워 가는 나만의 서재, 빙고판이 곧 책장 |
| 4 | **책갈피 빙고** | **Bookmark Bingo** | 읽은 책마다 책갈피를 꽂듯 칸에 표시하는 챌린지 |
| 5 | **오늘도 한 칸** | **One More Square** | "오늘도 한 칸만 더" — 부담 없이 이어 가는 독서 습관 |

> ✅ **확정: 1번 「한 줄 독서 (Read a Line)」** — 저장 키는 `readALine:v1`을 그대로 사용합니다.
